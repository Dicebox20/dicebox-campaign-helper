# The Mysterious Lodge: current campaign-only continuation

**Last bounded unit:** `mysterious-lodge-n3-two-stage-source-20261010` (owner-approved source patch and 39 local tests; Foundry was not changed).
**Next exact unit:** `MLODGE-N3-FIXTURE-INSTALL-001` (gated disposable-world installation and independent source readback; no installation without live authorized GM and backup).
**Handoff status:** complete locally. Independent, fresh persistent Codex CLI source-recovery exam passed 11/11 critical plus 1/1 optional; same session ID resume was verified. A separate new ChatGPT UI conversation has NOT been tested, and is an optional extra continuity confidence check, not a blocker to owner story review.

## User-approved story that must survive every handoff

Current title **The Mysterious Lodge**, originally **Central Lodge**. The players return from the Feywild and are led through a confusing mysterious forest to a Lodge owned by generations of devil-worshipping cultists. Resident Evil 1 and Devil May Cry inspire interconnected puzzle progression; Castle of Dreams is the prototype. The objective is to reach the final chamber, where the family is revealed alive and already summoning their master. The master's identity, family specifics, and what happens after reaching that ritual are **NOT DECIDED**. House of the Damned is a separate campaign.

## Recovered evidence and known limits

Read-only copied `dbx-test-world` audit: 21 Scenes, 202 Regions, 120 Region behaviors, 33 Items, 96 parsed structured puzzle interactions, 26 surviving decodable artworks. Those numbers describe the historical copied fixture, not a fresh live playthrough. Historical at-copy hashes drifted for 77 LevelDB working files after extraction; stable extracted reports are sealed separately.

Puzzle chain samples: E4 Black Garnet Eye → E1 hound; U2 Piano Roll → M2 player piano → Silver Family Emblem → M1 clock. Major risks: source-confirmed circular N3→T3 overlay/route fragment requirement with no validated alternate entrance, no assigned Scene backgrounds in the copied fixture despite artwork files, incomplete reciprocal railway transfers, and missing cult-family actors at F2. **Correction:** both presumed missing Item grant scripts were found nested in custom behaviors: Old Estate Survey from M2 Founder Portrait using E4 Founder's Signet, and Station Route Plate from N3 baggage locker using the M1 Brass Baggage Token. Their live Actor grants remain untested. Read the updated PUZZLE-ROUTES.md and `work/clscale-central-lodge-migration-v001/N3-DEPENDENCY-REVIEW-20261010.md`. Game runtime and multiplayer readiness are NOT verified.

## Continuity system verified

- Core source docs, SHA-256 seal, exact local CLI validator, chronological decision history, separate candidate exam and examiner rubric, and MAINTENANCE.md update procedure are present.
- Negative tests: 5/5 expected results, including STOP for missing file, unauthorized canon edit and false Scene count.
- The canonical knowledge SQLite was synchronized using SQLite's native backup method; integrity and 10-table exact comparison passed. The original backup and receipts remain preserved.
- Codex partner ID `01a128f9-b5f8-7340-a5b6-c2038edb1341` resumes explicitly through PowerShell; no autonomous/background execution is configured. Instructions: CODEX-PARTNER.md.
- A dated new portable ZIP with a candidate-only exam is the offline fallback, not the repository authority. Current package path: `outputs/mysterious-lodge-continuity-portable-20261010-v4.zip`.
- Continuity closure receipt: `work/clscale-central-lodge-migration-v001/cold-start-recovery-20261010/continuity-final-acceptance-receipt.json`. N3 source-audit receipt: `work/clscale-central-lodge-migration-v001/clscale-n3-dependency-audit-20261010.json`. **Newest N3 staged source acceptance:** `work/clscale-central-lodge-migration-v001/n3-two-stage-20261010/source-only-acceptance.json`. Two existing Behavior sources staged with pinned original SHA-256; original Item locations and original three-layer final gate preserved. New tests plus depot safety tests passed **39/39**. The approved change was synchronized to reproducible `database/seed.sql` and canonical KB with a guarded three-record-only comparison; receipt: `work/clscale-central-lodge-migration-v001/n3-two-stage-kb-20261010/kb-promotion-receipt.json`. No physical travel installed.

## Exactly what a successor should do

1. Read START-HERE.md, the foundation rules, CREATIVE-CANON.md, PUZZLE-ROUTES.md, CURRENT-STATE.json and this file; run `python tools/verify_mysterious_lodge_handoff.py` WITHOUT `--seal`.
2. In a genuinely fresh context, answer the candidate exam with source references. If it fails, STOP and repair the handoff rather than guessing.
3. The owner ALREADY APPROVED the two-stage N3 puzzle. For `MLODGE-N3-FIXTURE-INSTALL-001`, inspect the staged manifest, fresh original RegionBehavior source hashes and active authorized GM, verify exact fixture/world backup, and only then apply the exact two Behavior changes in disposable Foundry. Independently reread both persisted sources and test clean-state Region triggers. STOP if fixture offline or GM/owner consent/backup/source identity is unverified. The physical N3→T3 transfer is a different uninstalled safety-gated task; the source-only patch does not move tokens. Full storyline review remains open afterward.
4. On any approved change, use MAINTENANCE.md: record reason/player experience and puzzle relationships; append history, update state and this file, verify, deliberately reseal and rebuild a new versioned portable archive.
5. Foundry launch, import, native transfer, game DB mutations and multiplayer playtests require the existing exact-world and active-GM rules. Preserve player data and unrelated work. Do not overwrite the shared project-wide latest checkpoint solely for this campaign.

**Git boundary:** The parent repository has extensive unrelated uncommitted work. Handoff files are preserved on local disk and in the dated portable archive; Git publication/commit is NOT implied without independent single-writer/staging verification.
