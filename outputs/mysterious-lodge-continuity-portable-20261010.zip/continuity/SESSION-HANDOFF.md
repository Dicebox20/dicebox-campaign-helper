# Current campaign-only continuation: The Mysterious Lodge

**Last completed work unit:** 2026-10-10 candidate/examiner split and five-case cold-start regression; canonical SQLite synchronization and asset/story reconstruction were completed earlier on the same day. **This file deliberately does not follow global latest checkpoint changes** by DiceBox/Bridge/other campaigns.

## Already verified

A 109-file copied offline snapshot of dbx-test-world was inspected; 21 Scenes, 202 Regions, 120 Region behaviors, 33 Items, 96 structured puzzle interactions, 26 surviving artworks. Complete initial creative premise was freshly confirmed by the owner. No Foundry runtime or production world changes occurred during the audit. Detailed audit and companion artifacts are under work/clscale-central-lodge-migration-v001/story-reconstruction-audit-20261010/.

## Do not lose

Story: returned from Feywild; confusing forest leads to Lodge; generations of devil-worshipping cultists; family alive and already summoning master in last chamber. Objective is arrival at ritual. The aftermath is **undecided**. Resident Evil 1 + Devil May Cry puzzle influence, Castle of Dreams prototype, House of the Damned unrelated.

Technical uncertainty: missing background bindings in copied fixture; possible N3↔T3 progression cycle; two N3 item awards unproven; several route endpoints uninstalled; F2 family actors not staged; only static/offline acceptance. The last observed world-launch issue was a file lock on world.json held by the Remote Desktop Commander process; do not assume it persists or is resolved without live recheck.

## Knowledge-base synchronization verified

The reproducible seed was rebuilt in an isolated SQLite database and independently compared against the former canonical knowledge base. Exactly three new records were added (source, decision, open item), and no existing records were removed or changed. Windows blocked ordinary file replacement, so after a separate full rehearsal, **SQLite's native database backup API successfully promoted the rebuilt database**. Independent reread confirmed `PRAGMA integrity_check=ok` and exact equality of all 10 core knowledge tables. The original database backup remains intact. Canonical verification receipt: `work/clscale-central-lodge-migration-v001/mysterious-lodge-handoff-kb-backup-20261010-v002/sqlite-backup-api-once-receipt.json`. Earlier failed replacement evidence remains preserved. No Foundry world mutations were performed.

## Independent recovery testing

The candidate-only 12-question exam no longer contains its expected answers. The examiner rubric lives separately in work/clscale-central-lodge-migration-v001/cold-start-recovery-20261010/. A disposable-copy adversarial test returned 5/5 expected outcomes: pristine baseline accepted; unauthorized creative edit, missing puzzle document, and false Scene count rejected; rubric absent from candidate exam. These are mechanical checks, NOT a completed new-chat comprehension test. New chats must follow COLD-START-TEST.md, and can use the dated ZIP fallback described in PORTABLE-HANDOFF.md if Desktop Commander is unavailable.

## Exact next unit

1. In a clean/new chat, run the read-only handoff verifier and answer the COLD-START-EXAM. Report evidence paths and uncertainties, with NO Foundry writes.
2. Once continuity passes, review the owner-confirmed overall storyline against the recovered room-by-room audit, then choose one highest-impact **puzzle or creative gap** for owner reconciliation. Do not automatically move props/items or determine the ending.
3. Resume the approved four-step fast track only after that owner review and the original foundry authority/backup/GM/owner/transfer safety checks.

## End-of-turn recipe for future Foremen

Update CURRENT-STATE.json (last unit, next exact unit, changed source files, status, blockers), append any owner-confirmed new canon decision to DECISIONS.jsonl, edit creative canon only with owner approval, update this HANDOFF, run the verifier and reseal its content hashes with explicit --seal after intentional changes. Also follow project-wide acceptance/KB/checkpoint requirements. Keep the campaign pointer local rather than overwriting unrelated global work.
