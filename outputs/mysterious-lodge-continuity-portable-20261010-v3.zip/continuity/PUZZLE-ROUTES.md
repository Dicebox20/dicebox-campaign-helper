# Recovered puzzle and route relationships (not new creative canon)

**Evidence:** Offline snapshot copied from disposable dbx-test-world and extracted into sealed JSON reports, audited 2026-10-10. Important caveat: 77 originally hashed LevelDB files later changed/disappeared in the copied working folder after extraction. The original at-copy manifest is historical; the extracted JSON reports and art hashes are the stable handoff evidence. Read source catalog before implementation. Item existence, behaviors, or scripted success text DO NOT prove playability, scene entrances, runtime triggers, or physical artwork assignment.

## Recovered inventory

21 scenes, 202 Regions, **120** Region behaviors (119 original plus disabled N3 menu), 33 world Items, 5 Macros and 2 Journals. Recovered 96 structured action contracts, plus custom GM-mediated pickup and story scripts. There are 26 valid WebP files in the copied fixture's historical asset tree; zero of 21 Scene documents have a background/img binding in that fixture.

## Linked progression threads

1. **Arrival (E1) / graveyard (E4):** The stone hound lacks an eye; Black Garnet Eye is recovered in E4 and used at E1. The recovered script discloses an estate-plan fragment. The Glass Eye is a different object, recovered in U2, used at a founder portrait in M2.
2. **Household puzzle:** U2 Piano Roll → player piano in M2 → Silver Family Emblem → M1 clock. Separate custom 'Seventh Winter' clock code records solution 04:35. M1 clock compartment offers Family Reliquary Key and Brass Baggage Token. Key is described as opening M2 family reliquary, which yields the Ceremonial Censer.
3. **C1 chapel:** E4 Asmodean Covenant Seal + M2 Ceremonial Censer → both C1 sockets → C1 shrine completion/C2 unlock state. Recovered flavor mentions Asmodeus at shrine; the master's identity in the final room is NOT owner-confirmed.
4. **Exterior:** E2 Well Carving Pattern + B1 Water Control Wheel + E3 Fountain Valve Cap → E3 fountain gate. E4 mausoleum requires Stag Crest (M2), Rose (E3), Bell (M3) and Crown (U1). No claim yet that the four items are physically slotted in four separate Regions; this is an item-recovered gate.
5. **Rail power:** U1 House Proof + E3 Garden Proof + B1 Rail Proof → N1 three-proof station power → N2 estate-car travel enable. N3 menu exists but is DISABLED. T1/T2/T3 are separate walkable railway Scenes; exact reciprocal mouths remain unresolved/uninstalled.
6. **Depot/N3 (corrected by 2026-10-10 nested-script audit):** E4 four-crest mausoleum unlock yields the Founder's Signet. M2 Founder Portrait's serialized custom behavior checks that signet and then awards the **Old Estate Survey** via a nested pickup. N3 Brass Baggage Token locker similarly awards the **Station Route Plate** via a nested pickup after its socket succeeds. T2 holds the GM-confirmed Railway Switch Wheel. N3 cartography table wants Old Estate Survey, Cult Passage Diagram (C2), and Recent Route Fragment (T3). The overlay, departure board and switch wheel are required for N3→T3's **logical** unlock, which does not install or execute travel.
7. **F1/F2:** Assemble Infernal Cicada Body (C2) with Wings I (B2), II (E4), III (GM-mediated recovery in T1), IV (N3) at F1. GM confirms Measure/Ritual Rhythm, opening F1 inner ward. One installed F1→F2 native teleport exists but uses random landing and is not certified safe. F2 script confirms active ritual and living voices, with east/west anchors and north focus observations. No recovered cult-family actors/tokens.

## High-priority suspected breakages (not automatically repaired)

- **Source-confirmed N3/T3 cycle, no validated alternate entry:** N3→T3 needs a complete overlay; its Recent Route Fragment is recovered in T3, while the N3-to-T3 forward transfer is not installed. The T3 fast-travel choice is gated by the same flag; none of the four recovered native teleports enters T3. A non-documented alternate GM/manual entrance cannot be ruled out, but none is proven. Do not invent a route or move an Item without the owner's creative decision. See `work/clscale-central-lodge-migration-v001/N3-DEPENDENCY-REVIEW-20261010.md`.
- **Item-grant corrections:** Both supposedly missing item grants were located *nested inside custom RegionBehavior source*. Old Estate Survey: E4 Founder's Signet → M2 Founder Portrait; Station Route Plate: M1 Brass Baggage Token → N3 baggage locker. Static presence is verified; token-event triggering and actual Actor Item grants remain untested in Foundry. Do not repeat the older 'no pickup hooks' diagnosis.
- **Scene art:** 26 files decode and have hashes; 21 scene base map files are present, but zero scene background bindings in copied fixture. Four artworks appear as Tiles. Real visual QA and asset-placement verification remain open.
- **Cross-Scene navigation:** four native teleport behaviors (E1→M1, T3→N3, T3→F1, F1→F2) are installed/uncertified. Other reciprocal links, collision/elevation/footprint checks, one-shot intent and active GM/owner safety must be verified.
- **Final reveal:** F2 has observation script but family member identities and final scene staging remain open; the ending after reaching ritual is not decided.
- **Older state:** frozen State Ledger includes some preobserved values. Do not assume a clean fresh-campaign start without verified reset.

## Runtime and safety boundaries

The dedicated fixture world is dbx-test-world on localhost port 30005. This does not itself authorize launch, game data writes or online/multiplayer use. A past launch was blocked by a world.json Windows file lock owned by Desktop Commander; its CURRENT condition is UNKNOWN until rechecked. Production world assets are separate and must never be overwritten because a disposable fixture passes.

Before any repairs, inspect complete source and registered location IDs in full-evidence-catalog.json, enhanced-puzzle-interaction-audit.json, visual-artwork-file-manifest.json and clscale-railway-master-route-manifest-v002.json. Preserve user characters and foreign data. Never retry unknown teleport outcomes.
