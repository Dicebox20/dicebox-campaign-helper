# The Mysterious Lodge: current campaign-only continuation

**Last bounded unit:** `mysterious-lodge-continuity-closure-20261010`.
**Next exact unit:** `MLODGE-STORY-REVIEW-001` (owner review of the story and recovered progression, not automatic Foundry modification).
**Handoff status:** complete locally. Independent, fresh persistent Codex CLI source-recovery exam passed 11/11 critical plus 1/1 optional; same session ID resume was verified. A separate new ChatGPT UI conversation has NOT been tested, and is an optional extra continuity confidence check, not a blocker to owner story review.

## User-approved story that must survive every handoff

Current title **The Mysterious Lodge**, originally **Central Lodge**. The players return from the Feywild and are led through a confusing mysterious forest to a Lodge owned by generations of devil-worshipping cultists. Resident Evil 1 and Devil May Cry inspire interconnected puzzle progression; Castle of Dreams is the prototype. The objective is to reach the final chamber, where the family is revealed alive and already summoning their master. The master's identity, family specifics, and what happens after reaching that ritual are **NOT DECIDED**. House of the Damned is a separate campaign.

## Recovered evidence and known limits

Read-only copied `dbx-test-world` audit: 21 Scenes, 202 Regions, 120 Region behaviors, 33 Items, 96 parsed structured puzzle interactions, 26 surviving decodable artworks. Those numbers describe the historical copied fixture, not a fresh live playthrough. Historical at-copy hashes drifted for 77 LevelDB working files after extraction; stable extracted reports are sealed separately.

Puzzle chain samples: E4 Black Garnet Eye → E1 hound; U2 Piano Roll → M2 player piano → Silver Family Emblem → M1 clock. Major risks: possible circular N3→T3 overlay/route fragment requirement, unverified Old Estate Survey and Station Route Plate recovery, no assigned Scene backgrounds in the copied fixture despite artwork files, incomplete reciprocal railway transfers, and missing cult-family actors at F2. Game runtime and multiplayer readiness are NOT verified.

## Continuity system verified

- Core source docs, SHA-256 seal, exact local CLI validator, chronological decision history, separate candidate exam and examiner rubric, and MAINTENANCE.md update procedure are present.
- Negative tests: 5/5 expected results, including STOP for missing file, unauthorized canon edit and false Scene count.
- The canonical knowledge SQLite was synchronized using SQLite's native backup method; integrity and 10-table exact comparison passed. The original backup and receipts remain preserved.
- Codex partner ID `01a128f9-b5f8-7340-a5b6-c2038edb1341` resumes explicitly through PowerShell; no autonomous/background execution is configured. Instructions: CODEX-PARTNER.md.
- A dated new portable ZIP with a candidate-only exam is the offline fallback, not the repository authority. Current package path: `outputs/mysterious-lodge-continuity-portable-20261010-v2.zip`.
- Most recent closure receipt: `work/clscale-central-lodge-migration-v001/cold-start-recovery-20261010/continuity-final-acceptance-receipt.json`.

## Exactly what a successor should do

1. Read START-HERE.md, the foundation rules, CREATIVE-CANON.md, PUZZLE-ROUTES.md, CURRENT-STATE.json and this file; run `python tools/verify_mysterious_lodge_handoff.py` WITHOUT `--seal`.
2. In a genuinely fresh context, answer the candidate exam with source references. If it fails, STOP and repair the handoff rather than guessing.
3. For `MLODGE-STORY-REVIEW-001`, present the recovered full narrative progression to the owner and review gaps. Treat assistant ideas and script flavor as proposals, not established canon. Do not decide who the master is or force an ending.
4. On any approved change, use MAINTENANCE.md: record reason/player experience and puzzle relationships; append history, update state and this file, verify, deliberately reseal and rebuild a new versioned portable archive.
5. Foundry launch, import, native transfer, game DB mutations and multiplayer playtests require the existing exact-world and active-GM rules. Preserve player data and unrelated work. Do not overwrite the shared project-wide latest checkpoint solely for this campaign.

**Git boundary:** The parent repository has extensive unrelated uncommitted work. Handoff files are preserved on local disk and in the dated portable archive; Git publication/commit is NOT implied without independent single-writer/staging verification.
