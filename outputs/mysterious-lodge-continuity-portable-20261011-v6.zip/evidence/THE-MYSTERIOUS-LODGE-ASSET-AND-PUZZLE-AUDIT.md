# Mysterious Lodge, formerly Central Lodge: full technical puzzle inventory

EVIDENCE CLASS: read-only frozen copy of dbx-test-world, October 10, 2026. Not a completed in-game playthrough. All creative lore beyond owner-confirmed facts requires review.

## User-confirmed creative premise

The adventurers return from the Feywild, become disoriented in a mysterious forest, and reach the Lodge. Generations of devil-worshipping cultists own it. The puzzle and discovery structure draws from Resident Evil 1 and Devil May Cry; Castle of Dreams was the prototype. Reaching the final summoning room reveals the family still alive and summoning its master. The aftermath remains undecided.

## Inventory

21 Scenes; 202 Regions; 120 Region behaviors; 33 Items; 5 Macros; 2 Journals.
85 parsed structured interactions: gate 6, notice 27, observe 14, pickup 22, socket 16.

## All scenes and puzzle contracts

### B1 - Central Lodge — B1 Cellar & Utility Basement
ID 0CSBwzcszPKyaB8u; Regions 11; behaviors 4; tokens 1; walls 25; lights 3.
- PICKUP: DiceBox B1 — Rail Proof Recovery | Region B1 Rail Proof | key rail-proof | prerequisite none
- NOTICE: DiceBox B1 — Utility System Notice | Region B1 Utility System Notice | key b1.utility-system | prerequisite none
  Text: The basement machinery forms one connected water-control system. The wheel mounted at the control assembly is a removable component, while the drainage channels and flooded lower works answer to the same machinery.
- NOTICE: DiceBox B1 — Rail Proof Notice | Region B1 Rail Proof Notice | key b1.rail-proof | prerequisite none
  Text: Among the maintenance debris is something that does not belong to ordinary cellar work: old railway-related hardware and markings, handled often enough to suggest deliberate estate use rather than discarded scrap.
- PICKUP: DiceBox B1 Water Control Wheel Recovery | Region B1 Waterwheel | key water-control-wheel | prerequisite none

### B2 - Central Lodge — B2 Hidden Annex & Sacrificial Preparation Area
ID 5K1uASAARnX8aZhP; Regions 10; behaviors 5; tokens 1; walls 22; lights 3.
- OBSERVE: DiceBox B2 — recent-use-observation | Region B2 Recent Use Evidence | key puzzles.b2.recentUseObserved | prerequisite none
- OBSERVE: DiceBox B2 — sacrifice-evidence-observation | Region B2 Sacrifice Evidence | key puzzles.b2.sacrificeEvidenceInterpreted | prerequisite none
- NOTICE: DiceBox B2 — victim-history-notice | Region B2 Victim History Notice | key b2.victim-history | prerequisite none
  Text: The wash-room evidence is not random neglect. Several traces align with repeated preparation of unwilling occupants, enough to reconstruct part of the victims' history.
- NOTICE: DiceBox B2 — preparation-use-notice | Region B2 Preparation Use Notice | key b2.preparation-use | prerequisite none
  Text: The annex contradicts its apparent abandonment. Tools and surfaces were arranged for deliberate preparation, and some wear is much more recent than the surrounding decay.
- PICKUP: DiceBox B2 — cicada-wing-i-recovery | Region B2 Cicada Wing I | key cicada-wing-i | prerequisite none

### C1 - Central Lodge — C1 Hidden Chapel / Shrine of Asmodeus
ID EDdktL7VUihbpKe9; Regions 10; behaviors 6; tokens 1; walls 21; lights 3.
- OBSERVE: DiceBox C1 — devil-worship-interpretation | Region C1 Devil Worship Interpretation | key puzzles.c1.devilWorshipInterpreted | prerequisite none
- SOCKET: DiceBox C1 — ceremonial-censer-install | Region C1 Ceremonial Censer Socket | key ceremonial-censer | prerequisite none
  Text: The Ceremonial Censer settles into the shrine's prepared fitting.
- GATE: DiceBox C1 — shrine-completion-gate | Region C1 Shrine Completion | key puzzles.c1.shrineResolved | prerequisite puzzles.c1.covenantSealInstalled = True; puzzles.c1.ceremonialCenserInstalled = True
  Text: With the covenant seal and ceremonial censer restored to the shrine, the altar mechanism settles into alignment and the inner threshold releases.
- SOCKET: DiceBox C1 — covenant-seal-install | Region C1 Asmodean Covenant Seal Socket | key asmodean-covenant-seal | prerequisite none
  Text: The Asmodean Covenant Seal fits the prepared recess in the shrine.
- NOTICE: DiceBox C1 — shrine-incompleteness-notice | Region C1 Shrine Incompleteness Notice | key c1.shrine-incompleteness | prerequisite none
  Text: The shrine is incomplete by design rather than by simple damage. Two fitted ritual positions are conspicuously empty.
- NOTICE: DiceBox C1 — historical-use-notice | Region C1 Historical Use Notice | key c1.historical-use | prerequisite none
  Text: The chapel's marks of use span different periods. Old devotional wear is layered beneath signs that the shrine was returned to service much more recently.

### C2 - Central Lodge — C2 Cult Records & Ritual Undercroft
ID UNySMm7YkyYfh41x; Regions 11; behaviors 7; tokens 1; walls 30; lights 3.
- NOTICE: DiceBox C2 — concealed-record-category-notice | Region C2 Concealed Record Category Notice | key c2.concealed-record-category | prerequisite none
  Text: A category of records is concealed inside the archive's ordinary organization. The omissions repeat too consistently to be accidental.
- PICKUP: DiceBox C2 — infernal-cicada-body-recovery | Region C2 Infernal Cicada Body | key infernal-cicada-body | prerequisite none
- OBSERVE: DiceBox C2 — measure-rhythm-interpretation | Region C2 Measure / Ritual Rhythm | key puzzles.c2.measureRhythmInterpreted | prerequisite none
- PICKUP: DiceBox C2 — cult-passage-diagram-recovery | Region C2 Cult Passage Diagram | key cult-passage-diagram | prerequisite none
- OBSERVE: DiceBox C2 — cult-records-interpretation | Region C2 Cult Records Interpretation | key puzzles.c2.cultRecordsInterpreted | prerequisite none
- NOTICE: DiceBox C2 — record-recency-notice | Region C2 Record Recency Notice | key c2.record-recency | prerequisite none
  Text: The archive does not belong to a single period. Several records were handled, amended, or added far more recently than the surrounding material.
- SOCKET: DiceBox C2 — firstborn-pedestal | Region C2 Firstborn Pedestal | key child-bracelet | prerequisite none
  Text: The Child Bracelet fits the Firstborn pedestal. The memorial mechanism settles into its intended arrangement.

### E1 - Central Lodge — E1 Arrival Clearing & Front Grounds
ID Zq8iXByDVhHRbA7w; Regions 6; behaviors 4; tokens 4; walls 0; lights 0.
- SOCKET: DiceBox E1 — black-garnet-eye-install | Region E1 Hound Notice | key black-garnet-eye | prerequisite none
  Text: The Black Garnet Eye seats into the hound's empty socket. A concealed seam releases, exposing a hidden fragment of the old estate plan.
- NOTICE: DiceBox E1 — hound-notice | Region E1 Hound Notice | key e1.hound | prerequisite none
  Text: One of the stone hound's eyes is a dark inset. The other socket is precisely cut and empty rather than simply broken away.
- OBSERVE: DiceBox E1 — recent-use-observation | Region E1 Hound Notice | key puzzles.e1.recentUseObserved | prerequisite none

### E2 - Central Lodge — E2 Rear Service Yard & Outbuildings
ID sI4YVZZChgey1qNi; Regions 9; behaviors 5; tokens 2; walls 8; lights 2.
No structured interaction detected; inspect other script or visual assets.

### E3 - Central Lodge — E3 Formal Garden & Greenhouse
ID iqfCcDpEer4pwrJj; Regions 12; behaviors 8; tokens 1; walls 11; lights 2.
- PICKUP: DiceBox E3 Rose Crest Recovery | Region E3 Rose Funeral Crest | key rose-crest | prerequisite none
- NOTICE: DiceBox E3 Sundial Notice | Region E3 Sundial Notice | key e3.sundial | prerequisite none
  Text: The sundial is incomplete. Its center has a fitted socket where a removable metal gnomon should stand.
- PICKUP: DiceBox E3 Fountain Valve Cap Recovery | Region E3 Greenhouse Valve Cap | key fountain-valve-cap | prerequisite none
- SOCKET: DiceBox E3 Brass Gnomon | Region E3 Sundial Mechanism | key brass-gnomon | prerequisite none
  Text: The Brass Gnomon seats cleanly into the sundial. The mechanism settles into place and a concealed catch beneath the dial releases.
- PICKUP: DiceBox E3 Garden Proof Recovery | Region E3 Garden Proof | key garden-proof | prerequisite none
- NOTICE: DiceBox E3 Fountain Notice | Region E3 Fountain Notice | key e3.fountain | prerequisite none
  Text: The fountain is more mechanism than ornament. Its fittings and channels suggest an ordered control sequence rather than a simple valve.
- GATE: DiceBox E3 Fountain Sequence | Region E3 Fountain Sequence | key puzzles.e3.fountainResolved | prerequisite puzzles.e3.waterControlWheelInstalled = None; {'type': 'actorHasItem', 'itemKey': 'fountain-valve-cap'}; {'type': 'actorHasItem', 'itemKey': 'well-carving-pattern'}
  Text: Using the Well Carving Pattern as the operating sequence, you seat the Fountain Valve Cap and work the restored control wheel. Water shifts through hidden channels beneath the garden as the fountain mechanism settles into its resolved state.
- SOCKET: DiceBox E3 Water Control Wheel Installation | Region E3 Water Control Wheel | key water-control-wheel | prerequisite none
  Text: The Water Control Wheel from the basement fits the garden mechanism. The control spindle can now be operated.

### E4 - Central Lodge — E4 Family Graveyard & Crypt
ID DLcheEi6e5OHOYmU; Regions 11; behaviors 9; tokens 1; walls 11; lights 1.
- NOTICE: DiceBox E4 — child-burial-notice | Region E4 Child Burial Notice | key e4.child-burial | prerequisite none
  Text: A small detail at the child burial stands apart from the weathering around it, drawing attention to something that can still be recovered by careful search.
- PICKUP: DiceBox E4 — black-garnet-eye-recovery | Region E4 Black Garnet Eye | key black-garnet-eye | prerequisite none
- PICKUP: DiceBox E4 — child-bracelet-recovery | Region E4 Child Bracelet or Token | key child-bracelet | prerequisite none
- PICKUP: DiceBox E4 — covenant-seal-recovery | Region E4 Covenant Seal | key asmodean-covenant-seal | prerequisite none
- PICKUP: DiceBox E4 — cicada-wing-ii-recovery | Region E4 Cicada Wing II | key cicada-wing-ii | prerequisite none
- PICKUP: DiceBox E4 — founders-signet-recovery | Region E4 Founder's Signet | key founders-signet | prerequisite none
- OBSERVE: DiceBox E4 — false-burial-interpretation | Region E4 False Burial Evidence | key puzzles.e4.falseBurialInterpreted | prerequisite none
- GATE: DiceBox E4 — mausoleum-four-crest-gate | Region E4 Four-Crest Mausoleum Door | key puzzles.e4.mausoleumResolved | prerequisite {'type': 'itemRecovered', 'itemKey': 'stag-crest'}; {'type': 'itemRecovered', 'itemKey': 'rose-crest'}; {'type': 'itemRecovered', 'itemKey': 'bell-crest'}; {'type': 'itemRecovered', 'itemKey': 'crown-crest'}
  Text: The Stag, Rose, Bell, and Crown crests answer the mausoleum lock. Stone shifts behind the fittings and the crypt door releases.
- NOTICE: DiceBox E4 — false-burial-notice | Region E4 False Burial Notice | key e4.false-burial | prerequisite none
  Text: One burial arrangement is wrong: marker, grave, and surviving family record do not agree. The inconsistency is specific enough to warrant deliberate examination.

### F1 - F1 — Ancient Infernal Threshold
ID La9krMOMBhAhDLi6; Regions 6; behaviors 4; tokens 1; walls 27; lights 6.
No structured interaction detected; inspect other script or visual assets.

### F2 - F2 — Final Summoning Chamber
ID HWitOe1wSid7MZ1y; Regions 8; behaviors 4; tokens 1; walls 43; lights 8.
No structured interaction detected; inspect other script or visual assets.

### M1 - Central Lodge — M1 Entrance Hall & Great Room
ID U8S5ZrTjaPIkTUIL; Regions 12; behaviors 6; tokens 1; walls 9; lights 5.
- OBSERVE: DiceBox M1 — Clock Emblem Recess | Region M1 Clock Emblem Recess | key puzzles.m1.silverFamilyEmblemInstalled | prerequisite none
- NOTICE: DiceBox M1 — Grandfather Clock Notice | Region M1 Grandfather Clock Notice | key m1.grandfather-clock | prerequisite none
  Text: The grandfather clock is more deliberately constructed than the surrounding furniture. Part of its ornamentation is missing, leaving a shaped recess connected to the mechanism inside. Beneath the clock face an inscription reads: The last heir shall guide the little hand. The winters between our graves shall guide the great.
- PICKUP: DiceBox M1 — Clock Compartment: Baggage Token | Region M1 Clock Compartment | key brass-baggage-token | prerequisite none
- PICKUP: DiceBox M1 — Clock Compartment: Reliquary Key | Region M1 Clock Compartment | key family-reliquary-key | prerequisite none
- NOTICE: DiceBox M1 — Recent Disturbance Notice | Region M1 Recent Disturbance | key m1.recent-disturbance | prerequisite none
  Text: The decay here is uneven. Dust has been displaced recently, and one piece of furniture appears to have been shifted long after the room was supposedly abandoned. Someone has used this space far more recently than the rest of the Lodge suggests.

### M2 - Central Lodge — M2 Study, Parlor & Formal Rooms
ID JZkxX6lUQe8Nc8xJ; Regions 15; behaviors 7; tokens 1; walls 12; lights 6.
- OBSERVE: DiceBox M2 — Portrait Eye Mechanism | Region M2 Portrait Eye | key puzzles.m2.glassEyeInstalled | prerequisite none
- NOTICE: DiceBox M2 — Founder Portrait Signet | Region M2 Founder Portrait | key m2.portrait-eye | prerequisite none
  Text: The founder’s portrait is subtly wrong. One eye does not match the other, and close inspection reveals a fitted recess where a small artificial eye was meant to sit.
- PICKUP: DiceBox M2 — Stag Crest Recovery | Region M2 Stag Crest | key stag-crest | prerequisite none
- NOTICE: DiceBox M2 — Player Piano Notice | Region M2 Player Piano Notice | key m2.player-piano | prerequisite none
  Text: The player piano is intact, but its mechanism is incomplete. The reader assembly is empty and clearly shaped to accept a perforated music roll.
- NOTICE: DiceBox M2 — Portrait Notice | Region M2 Portrait Notice | key m2.portrait-eye | prerequisite none | DISABLED
  Text: The founder’s portrait is subtly wrong. One eye does not match the other, and close inspection reveals a fitted recess where a small artificial eye was meant to sit.
- PICKUP: DiceBox M2 — Family Reliquary | Region M2 Family Reliquary | key ceremonial-censer | prerequisite none
- PICKUP: DiceBox M2 — Piano Roll Mechanism | Region M2 Piano Roll Mechanism | key silver-family-emblem | prerequisite none

### M3 - Central Lodge — M3 Kitchen & Service Wing
ID LXTA8mx1rJ2L6e2J; Regions 10; behaviors 4; tokens 1; walls 14; lights 4.
- SOCKET: DiceBox M3 — Servant Bell Pull Installation | Region M3 Bell Pull Fitting | key servant-bell-pull | prerequisite none
  Text: The Servant Bell Pull fits the weathered bracket. The restored line takes tension, and the bell board mechanism can now respond.
- PICKUP: DiceBox M3 — Bell Crest Recovery | Region M3 Bell Crest | key bell-crest | prerequisite none
- NOTICE: DiceBox M3 — Recent Use Notice | Region M3 Recent Use | key m3.recent-use | prerequisite none
  Text: The kitchen's neglect is uneven. Dust has been disturbed around a service surface, and a few practical objects were moved recently enough to stand out from the surrounding decay. Someone has used this wing more recently than the rest of the Lodge suggests.
- NOTICE: DiceBox M3 — Bell Board Notice | Region M3 Bell Board Notice | key m3.bell-board | prerequisite none
  Text: The servant bell board is incomplete. One line ends at an empty fitting where a pull should attach, and the surrounding mechanism appears designed to respond when that line is restored.

### N1 - Central Lodge — N1 Underworks Hub / Lodge Railway Station
ID MAbLfBqG7qIVVuLN; Regions 11; behaviors 7; tokens 1; walls 14; lights 5.
- SOCKET: DiceBox N1 — rail-proof-install | Region N1 Rail Proof Socket | key rail-proof | prerequisite none
  Text: The Rail Proof seats into the third authorization fitting.
- OBSERVE: DiceBox N1 — estate-railway-interpretation | Region N1 Estate Railway Interpretation | key puzzles.n1.estateRailwayInterpreted | prerequisite none
- SOCKET: DiceBox N1 — house-proof-install | Region N1 House Proof Socket | key house-proof | prerequisite none
  Text: The House Proof seats into the first authorization fitting.
- NOTICE: DiceBox N1 — walkable-railway-notice | Region N1 Walkable Railway Notice | key n1.walkable-railway | prerequisite none
  Text: The railway is not merely a service track. Clear pedestrian margins, maintenance access, and repeated foot wear show that people were expected to move through these tunnels on foot.
- NOTICE: DiceBox N1 — station-power-notice | Region N1 Station Power Notice | key n1.station-power | prerequisite none
  Text: The station control bank is dormant, but not ruined. Three distinct proof fittings are wired into the same power authorization circuit.
- GATE: DiceBox N1 — three-proof-station-power | Region N1 Three-Proof Station Power | key puzzles.n1.railwayPowered | prerequisite puzzles.n1.proofs.house = True; puzzles.n1.proofs.garden = True; puzzles.n1.proofs.rail = True
  Text: With House, Garden, and Rail proofs accepted, the station authorization circuit closes and railway power comes online.
- SOCKET: DiceBox N1 — garden-proof-install | Region N1 Garden Proof Socket | key garden-proof | prerequisite none
  Text: The Garden Proof seats into the second authorization fitting.

### N2 - Central Lodge — N2 Underground Grotto / Garden Station
ID 4pc5akMBieHU7GvV; Regions 9; behaviors 4; tokens 1; walls 36; lights 4.
- OBSERVE: DiceBox N2 — grotto-station-interpretation | Region N2 Grotto Station Interpretation | key puzzles.n2.grottoStationInterpreted | prerequisite none
- GATE: DiceBox N2 — rail-car-fast-travel-enable | Region N2 Estate Rail Car State | key puzzles.n2.fastTravelEnabled | prerequisite puzzles.n1.railwayPowered = True
  Text: With railway power available from the Lodge station, the estate rail car is ready for station-to-station travel.
- NOTICE: DiceBox N2 — walkable-margin-notice | Region N2 Walkable Railway Margin Notice | key n2.walkable-margin | prerequisite none
  Text: The rail bed leaves a deliberate pedestrian margin through the grotto. The route was built for people to walk alongside the line, not only for the estate car.
- NOTICE: DiceBox N2 — flood-drainage-notice | Region N2 Flood and Drainage Evidence Notice | key n2.flood-drainage | prerequisite none
  Text: Water damage and drainage marks show that the lower grotto's flooding is tied to the Lodge's utility system rather than a permanent natural waterline.

### N3 - Central Lodge — N3 Collection Vaults / Underground Depot
ID pHQvDUDlyWZFuNrX; Regions 12; behaviors 13; tokens 1; walls 34; lights 5.
- SOCKET: DiceBox N3 — railway-switch-wheel-install | Region N3 Railway Switch Mechanism | key railway-switch-wheel | prerequisite none
  Text: The Railway Switch Wheel fits the depot switch mechanism.
- SOCKET: DiceBox N3 — baggage-token-route-plate | Region N3 Baggage Locker Anomaly | key brass-baggage-token | prerequisite none
  Text: The Brass Baggage Token trips the locker mechanism.
- OBSERVE: DiceBox N3 — baggage-locker-observation | Region N3 Baggage Locker Anomaly | key puzzles.n3.baggageLockerObserved | prerequisite none
- PICKUP: DiceBox N3 — cicada-wing-iv-recovery | Region N3 Cicada Wing IV | key cicada-wing-iv | prerequisite none
- OBSERVE: DiceBox N3 — recent-use-observation | Region N3 Recent Use Contradiction | key puzzles.n3.recentUseObserved | prerequisite none
- GATE: DiceBox N3 — cartography-route-overlay | Region N3 Cartography Table | key puzzles.n3.routeOverlay.resolved | prerequisite puzzles.n3.routeOverlay.oldEstateSurvey = True; puzzles.n3.routeOverlay.cultPassageDiagram = True; puzzles.n3.routeOverlay.recentRouteFragment = True
  Text: The three route sources align into a coherent hidden-route overlay.
- SOCKET: DiceBox N3 — cartography-cult-passage-diagram | Region N3 Cartography Table | key cult-passage-diagram | prerequisite none
  Text: The Cult Passage Diagram aligns with the second cartographic layer.
- SOCKET: DiceBox N3 — cartography-old-estate-survey | Region N3 Cartography Table | key old-estate-survey | prerequisite none
  Text: The Old Estate Survey aligns with the first cartographic layer.
- SOCKET: DiceBox N3 — cartography-recent-route-fragment | Region N3 Cartography Table | key recent-route-fragment | prerequisite none
  Text: The Recent Route Fragment aligns with the final cartographic layer.
- SOCKET: DiceBox N3 — departure-board-route-plate | Region N3 Departure Board Mechanism | key station-route-plate | prerequisite none
  Text: The Station Route Plate locks into the departure board and restores its route markings.
- NOTICE: DiceBox N3 — walkable-railway-notice | Region N3 Walkable Railway Notice | key n3.walkable-railway | prerequisite none
  Text: The depot track geometry again preserves clear pedestrian movement beside the rails, confirming the hidden line was meant to be walked as well as ridden.

### T1 - T1 - Lodge ↔ Grotto Walkable Railway Tunnel
ID ImeIdHbYb6kZKAdt; Regions 6; behaviors 3; tokens 0; walls 22; lights 6.
No structured interaction detected; inspect other script or visual assets.

### T2 - T2 - Grotto ↔ Depot Walkable Railway Tunnel
ID ez9MSQ8QIO4cW6zo; Regions 6; behaviors 3; tokens 0; walls 24; lights 6.
No structured interaction detected; inspect other script or visual assets.

### T3 - T3 - Abandoned Spur / Cult Railway Extension
ID aIKQmFiuXWipEdyb; Regions 6; behaviors 5; tokens 0; walls 32; lights 6.
No structured interaction detected; inspect other script or visual assets.

### U1 - Central Lodge — U1 Family & Guest Rooms
ID if9iWDRjSwI87EeX; Regions 10; behaviors 5; tokens 1; walls 22; lights 5.
- NOTICE: DiceBox U1 — Guest Room Absence Notice | Region U1 Guest Room Absence Notice | key u1.guest-room-absence | prerequisite none
  Text: One guest room contradicts itself. It is furnished for regular occupation, but the wear, dust, and personal traces expected from a long-term occupant are missing. The absence feels deliberate rather than merely abandoned.
- OBSERVE: DiceBox U1 — Family Records Interpretation | Region U1 Family Records | key puzzles.u1.familyRecordsInterpreted | prerequisite none
- PICKUP: DiceBox U1 — House Proof Recovery | Region U1 House Proof | key house-proof | prerequisite none
- PICKUP: DiceBox U1 — Crown Crest Recovery | Region U1 Crown Crest | key crown-crest | prerequisite none
- NOTICE: DiceBox U1 — Family Records Notice | Region U1 Family Records Notice | key u1.family-records | prerequisite none
  Text: The family records are not simply disordered by age. A gap in the sequence and an unusual grouping of names stand out from the surrounding entries, suggesting that part of the household history was organized or omitted deliberately.

### U2 - Central Lodge — U2 Servants’ Quarters, Nursery & Attic
ID PVf6Gbrv9HbB88uZ; Regions 11; behaviors 7; tokens 1; walls 27; lights 3.
No structured interaction detected; inspect other script or visual assets.

## Puzzle prerequisite links

- STATE items.asmodean-covenant-seal.recovered; initial False
  writers: E4 DiceBox E4 — covenant-seal-recovery
  readers: none
- STATE items.bell-crest.recovered; initial False
  writers: M3 DiceBox M3 — Bell Crest Recovery
  readers: none
- STATE items.black-garnet-eye.recovered; initial False
  writers: E4 DiceBox E4 — black-garnet-eye-recovery
  readers: none
- STATE items.child-bracelet.recovered; initial False
  writers: E4 DiceBox E4 — child-bracelet-recovery
  readers: none
- STATE items.cicada-wing-i.recovered; initial False
  writers: B2 DiceBox B2 — cicada-wing-i-recovery
  readers: none
- STATE items.cicada-wing-ii.recovered; initial False
  writers: E4 DiceBox E4 — cicada-wing-ii-recovery
  readers: none
- STATE items.cicada-wing-iv.recovered; initial False
  writers: N3 DiceBox N3 — cicada-wing-iv-recovery
  readers: none
- STATE items.crown-crest.recovered; initial False
  writers: U1 DiceBox U1 — Crown Crest Recovery
  readers: none
- STATE items.cult-passage-diagram.recovered; initial False
  writers: C2 DiceBox C2 — cult-passage-diagram-recovery
  readers: none
- STATE items.founders-signet.recovered; initial False
  writers: E4 DiceBox E4 — founders-signet-recovery
  readers: none
- STATE items.fountain-valve-cap.recovered; initial False
  writers: E3 DiceBox E3 Fountain Valve Cap Recovery
  readers: none
- STATE items.garden-proof.recovered; initial False
  writers: E3 DiceBox E3 Garden Proof Recovery
  readers: none
- STATE items.house-proof.recovered; initial False
  writers: U1 DiceBox U1 — House Proof Recovery
  readers: none
- STATE items.infernal-cicada-body.recovered; initial False
  writers: C2 DiceBox C2 — infernal-cicada-body-recovery
  readers: none
- STATE items.rail-proof.recovered; initial False
  writers: B1 DiceBox B1 — Rail Proof Recovery
  readers: none
- STATE items.rose-crest.recovered; initial False
  writers: E3 DiceBox E3 Rose Crest Recovery
  readers: none
- STATE items.water-control-wheel.recovered; initial False
  writers: B1 DiceBox B1 Water Control Wheel Recovery
  readers: none
- STATE puzzles.b2.recentUseObserved; initial False
  writers: B2 DiceBox B2 — recent-use-observation
  readers: none
- STATE puzzles.b2.sacrificeEvidenceInterpreted; initial False
  writers: B2 DiceBox B2 — sacrifice-evidence-observation
  readers: none
- STATE puzzles.c1.ceremonialCenserInstalled; initial False
  writers: C1 DiceBox C1 — ceremonial-censer-install
  readers: C1 DiceBox C1 — shrine-completion-gate
- STATE puzzles.c1.covenantSealInstalled; initial False
  writers: C1 DiceBox C1 — covenant-seal-install
  readers: C1 DiceBox C1 — shrine-completion-gate
- STATE puzzles.c1.devilWorshipInterpreted; initial False
  writers: C1 DiceBox C1 — devil-worship-interpretation
  readers: none
- STATE puzzles.c1.shrineResolved; initial False
  writers: C1 DiceBox C1 — shrine-completion-gate
  readers: none
- STATE puzzles.c2.cultRecordsInterpreted; initial False
  writers: C2 DiceBox C2 — cult-records-interpretation
  readers: none
- STATE puzzles.c2.firstbornPedestalResolved; initial False
  writers: C2 DiceBox C2 — firstborn-pedestal
  readers: none
- STATE puzzles.c2.measureRhythmInterpreted; initial False
  writers: C2 DiceBox C2 — measure-rhythm-interpretation
  readers: none
- STATE puzzles.e1.blackGarnetEyeInstalled; initial False
  writers: E1 DiceBox E1 — black-garnet-eye-install
  readers: none
- STATE puzzles.e1.recentUseObserved; initial True
  writers: E1 DiceBox E1 — recent-use-observation
  readers: none
- STATE puzzles.e3.fountainResolved; initial False
  writers: E3 DiceBox E3 Fountain Sequence
  readers: none
- STATE puzzles.e3.sundialResolved; initial False
  writers: E3 DiceBox E3 Brass Gnomon
  readers: none
- STATE puzzles.e3.waterControlWheelInstalled; initial False
  writers: E3 DiceBox E3 Water Control Wheel Installation
  readers: E3 DiceBox E3 Fountain Sequence
- STATE puzzles.e4.falseBurialInterpreted; initial False
  writers: E4 DiceBox E4 — false-burial-interpretation
  readers: none
- STATE puzzles.e4.mausoleumResolved; initial False
  writers: E4 DiceBox E4 — mausoleum-four-crest-gate
  readers: none
- STATE puzzles.m1.clockCompartmentOpened; initial False
  writers: M1 DiceBox M1 — Clock Compartment: Baggage Token; M1 DiceBox M1 — Clock Compartment: Reliquary Key
  readers: none
- STATE puzzles.m1.silverFamilyEmblemInstalled; initial False
  writers: M1 DiceBox M1 — Clock Emblem Recess
  readers: none
- STATE puzzles.m2.glassEyeInstalled; initial False
  writers: M2 DiceBox M2 — Portrait Eye Mechanism
  readers: none
- STATE puzzles.m2.pianoRollInstalled; initial False
  writers: M2 DiceBox M2 — Piano Roll Mechanism
  readers: none
- STATE puzzles.m2.reliquaryUnlocked; initial False
  writers: M2 DiceBox M2 — Family Reliquary
  readers: none
- STATE puzzles.m3.servantBellPullInstalled; initial False
  writers: M3 DiceBox M3 — Servant Bell Pull Installation
  readers: none
- STATE puzzles.n1.estateRailwayInterpreted; initial False
  writers: N1 DiceBox N1 — estate-railway-interpretation
  readers: none
- STATE puzzles.n1.proofs.garden; initial False
  writers: N1 DiceBox N1 — garden-proof-install
  readers: N1 DiceBox N1 — three-proof-station-power
- STATE puzzles.n1.proofs.house; initial False
  writers: N1 DiceBox N1 — house-proof-install
  readers: N1 DiceBox N1 — three-proof-station-power
- STATE puzzles.n1.proofs.rail; initial False
  writers: N1 DiceBox N1 — rail-proof-install
  readers: N1 DiceBox N1 — three-proof-station-power
- STATE puzzles.n1.railwayPowered; initial False
  writers: N1 DiceBox N1 — three-proof-station-power
  readers: N2 DiceBox N2 — rail-car-fast-travel-enable
- STATE puzzles.n2.fastTravelEnabled; initial False
  writers: N2 DiceBox N2 — rail-car-fast-travel-enable
  readers: none
- STATE puzzles.n2.grottoStationInterpreted; initial False
  writers: N2 DiceBox N2 — grotto-station-interpretation
  readers: none
- STATE puzzles.n3.baggageLockerObserved; initial False
  writers: N3 DiceBox N3 — baggage-locker-observation
  readers: none
- STATE puzzles.n3.baggageTokenAccepted; initial False
  writers: N3 DiceBox N3 — baggage-token-route-plate
  readers: none
- STATE puzzles.n3.departureBoardResolved; initial False
  writers: N3 DiceBox N3 — departure-board-route-plate
  readers: none
- STATE puzzles.n3.recentUseObserved; initial False
  writers: N3 DiceBox N3 — recent-use-observation
  readers: none
- STATE puzzles.n3.routeOverlay.cultPassageDiagram; initial False
  writers: N3 DiceBox N3 — cartography-cult-passage-diagram
  readers: N3 DiceBox N3 — cartography-route-overlay
- STATE puzzles.n3.routeOverlay.oldEstateSurvey; initial False
  writers: N3 DiceBox N3 — cartography-old-estate-survey
  readers: N3 DiceBox N3 — cartography-route-overlay
- STATE puzzles.n3.routeOverlay.recentRouteFragment; initial False
  writers: N3 DiceBox N3 — cartography-recent-route-fragment
  readers: N3 DiceBox N3 — cartography-route-overlay
- STATE puzzles.n3.routeOverlay.resolved; initial False
  writers: N3 DiceBox N3 — cartography-route-overlay
  readers: none
- STATE puzzles.n3.switchWheelInstalled; initial False
  writers: N3 DiceBox N3 — railway-switch-wheel-install
  readers: none
- STATE puzzles.u1.familyRecordsInterpreted; initial False
  writers: U1 DiceBox U1 — Family Records Interpretation
  readers: none

## All campaign items

- Asmodean Covenant Seal [asmodean-covenant-seal] ID JlbmnEzcBvLsdL9f
  Pickup: E4 E4 Covenant Seal
  Socket: C1 C1 Asmodean Covenant Seal Socket
- Bell Crest [bell-crest] ID XuWFfHIcAUVNsiEo
  Pickup: M3 M3 Bell Crest
  Socket: NO MATCHED SOCKET
- Black Garnet Eye [black-garnet-eye] ID MPXpG8mQpyUbYmOm
  Pickup: E4 E4 Black Garnet Eye
  Socket: E1 E1 Hound Notice
- Brass Baggage Token [brass-baggage-token] ID 0kQdvlq6DxuNdw0n
  Pickup: M1 M1 Clock Compartment
  Socket: N3 N3 Baggage Locker Anomaly
- Brass Gnomon [brass-gnomon] ID Pgj2gXaVKvas3HY1
  Pickup: NO MATCHED PICKUP
  Socket: E3 E3 Sundial Mechanism
- Ceremonial Censer [ceremonial-censer] ID a8cs9EYDuYt2yPE5
  Pickup: M2 M2 Family Reliquary
  Socket: C1 C1 Ceremonial Censer Socket
- Child Bracelet [child-bracelet] ID OhafRRkDxTKKtZGl
  Pickup: E4 E4 Child Bracelet or Token
  Socket: C2 C2 Firstborn Pedestal
- Crown Crest [crown-crest] ID sJOCI8xp0zR70ODd
  Pickup: U1 U1 Crown Crest
  Socket: NO MATCHED SOCKET
- Cult Passage Diagram [cult-passage-diagram] ID zHP6ARf6vKV3RTt7
  Pickup: C2 C2 Cult Passage Diagram
  Socket: N3 N3 Cartography Table
- Family Reliquary Key [family-reliquary-key] ID m3D1DsbLspDar5Jb
  Pickup: M1 M1 Clock Compartment
  Socket: NO MATCHED SOCKET
- Founder’s Signet [founders-signet] ID l34clFAPFCWfyGFT
  Pickup: E4 E4 Founder's Signet
  Socket: NO MATCHED SOCKET
- Fountain Valve Cap [fountain-valve-cap] ID kMxDAIJy3E6yH5Kd
  Pickup: E3 E3 Greenhouse Valve Cap
  Socket: NO MATCHED SOCKET
- Garden Proof [garden-proof] ID epEmys76We97Adnt
  Pickup: E3 E3 Garden Proof
  Socket: N1 N1 Garden Proof Socket
- Glass Eye [glass-eye] ID 50ZN4MZDzGHnZHwv
  Pickup: NO MATCHED PICKUP
  Socket: NO MATCHED SOCKET
- House Proof [house-proof] ID mszo9eSqFhAW3w1A
  Pickup: U1 U1 House Proof
  Socket: N1 N1 House Proof Socket
- Infernal Cicada Body [infernal-cicada-body] ID ah6NWaYxtwIUVPXn
  Pickup: C2 C2 Infernal Cicada Body
  Socket: NO MATCHED SOCKET
- Infernal Cicada Wing I [cicada-wing-i] ID eIECLKMQwEjScWG7
  Pickup: B2 B2 Cicada Wing I
  Socket: NO MATCHED SOCKET
- Infernal Cicada Wing II [cicada-wing-ii] ID v7vXPvrditUHiTJY
  Pickup: E4 E4 Cicada Wing II
  Socket: NO MATCHED SOCKET
- Infernal Cicada Wing III [cicada-wing-iii] ID 6FS6ydZku6EJSpF2
  Pickup: NO MATCHED PICKUP
  Socket: NO MATCHED SOCKET
- Infernal Cicada Wing IV [cicada-wing-iv] ID Oav2JovgXMOrrVsS
  Pickup: N3 N3 Cicada Wing IV
  Socket: NO MATCHED SOCKET
- Iron Hand Crank [iron-hand-crank] ID 6pGa8jrGD9WP6zGj
  Pickup: NO MATCHED PICKUP
  Socket: NO MATCHED SOCKET
- Old Estate Survey [old-estate-survey] ID fc3iLVvzHbiaXGsB
  Pickup: NO MATCHED PICKUP
  Socket: N3 N3 Cartography Table
- Piano Roll [piano-roll] ID fAnRnn7C6WlPcjJm
  Pickup: NO MATCHED PICKUP
  Socket: NO MATCHED SOCKET
- Rail Proof [rail-proof] ID 26fLgiWHkz8i2mzw
  Pickup: B1 B1 Rail Proof
  Socket: N1 N1 Rail Proof Socket
- Railway Switch Wheel [railway-switch-wheel] ID JrDy7pZP0QkLWaFy
  Pickup: NO MATCHED PICKUP
  Socket: N3 N3 Railway Switch Mechanism
- Recent Route Fragment [recent-route-fragment] ID pCRasmemswNMNrEX
  Pickup: NO MATCHED PICKUP
  Socket: N3 N3 Cartography Table
- Rose Crest [rose-crest] ID w0sVrDXA6BqXp5iy
  Pickup: E3 E3 Rose Funeral Crest
  Socket: NO MATCHED SOCKET
- Servant Bell Pull [servant-bell-pull] ID 1bOamz1iyqBF12UF
  Pickup: NO MATCHED PICKUP
  Socket: M3 M3 Bell Pull Fitting
- Silver Family Emblem [silver-family-emblem] ID TPQYoo09bKBHi362
  Pickup: M2 M2 Piano Roll Mechanism
  Socket: NO MATCHED SOCKET
- Stag Crest [stag-crest] ID PiTkaXMYHjLL7loi
  Pickup: M2 M2 Stag Crest
  Socket: NO MATCHED SOCKET
- Station Route Plate [station-route-plate] ID mmrZXHQTAFb43zcX
  Pickup: NO MATCHED PICKUP
  Socket: N3 N3 Departure Board Mechanism
- Water Control Wheel [water-control-wheel] ID 9JvaReTwRO0ngOhg
  Pickup: B1 B1 Waterwheel
  Socket: E3 E3 Water Control Wheel
- Well Carving Pattern [well-carving-pattern] ID nMg768uyhzpeVAQh
  Pickup: NO MATCHED PICKUP
  Socket: NO MATCHED SOCKET

## Native transitions and release blockers

- F1 — Ancient Infernal Threshold / F1 — Transition — Inner Threshold to F2 / DiceBox F1 — Transition to Final Summoning Chamber -> HWitOe1wSid7MZ1y
- Central Lodge — E1 Arrival Clearing & Front Grounds / E1 Lodge Entrance / DiceBox CL-50 — Enter Main Lodge from E1 (GM Confirmed) -> 
- T3 - Abandoned Spur / Cult Railway Extension / T3 Ancient Passage Mouth / DiceBox CL-50 — Ancient Passage to F1 (GM Confirmed) -> 
- T3 - Abandoned Spur / Cult Railway Extension / T3 N3 Branch Mouth / DiceBox CL-50 — Return from T3 to N3 (GM Confirmed) -> 
There are only four native teleport behavior scripts in the fixture. Most other Scene connections are still not demonstrated as working. The disabled depot menu is not live travel.
The ritual and family reveal require manual creative and runtime audit; reaching F2 is not equivalent to completing the campaign.

## Evidence boundary

A structured contract or item proves installed data, not a reachable puzzle. Missing source links, uninstalled transfers, unavailable item pickups, and quarantined kernel transitions must be tested individually.
