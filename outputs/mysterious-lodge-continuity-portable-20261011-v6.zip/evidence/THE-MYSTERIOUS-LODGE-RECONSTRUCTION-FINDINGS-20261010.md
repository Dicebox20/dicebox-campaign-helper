# The Mysterious Lodge: reconstructed narrative, assets and progression findings

**Audit source:** read-only, verified 109-file (2,839,378-byte) copy of stopped Foundry test world `dbx-test-world`, plus existing route manifests and 26 original WebP image files. No Foundry world modifications made. Report date: 2026-10-10.

**Evidence status:** full offline inventory and source-logic reconstruction of the copied fixture, **not** a full visual-in-Foundry audit or complete player playthrough. Original source campaign and all archived chat history have not been exhaustively compared. Distinguish user-approved creative canon from imported script flavor and technical plans.

## User-approved campaign premise

Players return from the Feywild. A disorienting mysterious forest directs them to the mysterious lodge. The Lodge is owned by generations of devil-worshipping cultists. Resident Evil 1 and Devil May Cry provide the puzzle-progression inspiration; Castle of Dreams is the prototype. The objective is to reach the final chamber and discover the supposedly absent family is alive and already summoning their master. What happens after discovering the ritual is explicitly undecided. House of the Damned is a different campaign.

## Technical inventory, independently extracted

- **21 Scenes:** E1–E4 outdoor; M1–M3 main; U1–U2 upper; B1–B2 basement; C1–C2 cult; N1–N3 railway stops; T1–T3 tunnel paths; F1 ancient threshold; F2 final summoning.
- **202 Regions, 120 Region behaviors, 33 registered world Items, 5 Macros, 2 Journals**, with runtime Kernel and State Ledger present.
- 96 structured contracts recovered (28 pickups, 30 notices, 16 observations, 16 sockets, 6 gates); three additional GM-adjudicated custom pickup scripts for Cicada Wing III (T1), Railway Switch Wheel (T2), and Recent Route Fragment (T3), plus other custom F1/F2, clue and clock scripts.
- **26 distinct WebP artworks** present and decodable, covering 21 base Scene maps, day/night variations for E2/E3/E4, and missing/restored hound-statue variants. Image dimensions/hashes in visual-artwork-file-manifest.json.
- **No Scene background / main image assigned in any of the 21 test-world Scene documents.** Only four of the 26 related art assets are referenced through existing Tiles. Thus artwork *exists* but the copied fixture does not demonstrate 21 visually configured Scenes. Other ambient resources: 86 lights, zero scene sound documents, and five Tiles total. One Tile has an unresolved Data/b1-waterwheel-tile.webp path relative to the fixture data root.
- Six imported Actor documents are player/test-related, including Carp Alderleaf. The F2 Scene has one Sir Toppleton token, not a set of cult-family combatants.

## Reconstructed connected puzzle structure

1. **Arrival and false abandonment:** E1 hound missing eye; E4 crypt holds Black Garnet Eye; installing it at E1 reveals a concealed estate-plan fragment. Rooms E1/M1/M3/E2/U1/U2/B2/C2/E4/N3 contain clues contradicting the Lodge's apparent abandonment. The family-secret reveal is foreshadowed by fresh activity, missing records and false burial evidence.
2. **Household and clock:** U2 contains Glass Eye and Piano Roll. Glass Eye is used at M2 portrait; Piano Roll operates M2 player piano and yields Silver Family Emblem; emblem is used at M1 grandfather clock. The custom 'Seventh Winter' clock script specifies 04:35, and the clock compartment has Family Reliquary Key plus Brass Baggage Token. M2 reliquary yields Ceremonial Censer; E4 contains Asmodean Covenant Seal. Both fit C1 shrine, logically marking C2 unlocked.
3. **Garden and exterior:** E2 Well Carving Pattern + B1 Water Control Wheel + E3 Fountain Valve Cap feed the E3 fountain sequence. Four crests from M2 (Stag), E3 (Rose), M3 (Bell), and U1 (Crown) satisfy the E4 mausoleum gate.
4. **Railway:** U1 House Proof, E3 Garden Proof and B1 Rail Proof install at N1; all three enable railway power; N2 then enables estate-car fast travel. Physical T1/T2 walkable railway passages exist as Scenes but endpoint-bound reciprocal transitions are not installed/certified. N3 has a disabled destination-menu preview, a baggage-token locker and a route-overlay table.
5. **Depot hidden spur:** N3 departure board uses Station Route Plate, branch switch uses Railway Switch Wheel recovered in T2, and route overlay needs Old Estate Survey + Cult Passage Diagram (C2) + Recent Route Fragment (T3). Hidden spur N3→T3 requires departure board, switch wheel and completed overlay.
6. **Infernal threshold:** Cicada Body (C2) and Wings I (B2), II (E4), III (T1), IV (N3) are installed at F1. GM-confirmed Measure/Ritual Rhythm resolves F1 inner ward, and F1→F2 native teleport is installed with random arrival.
7. **Final summoning:** F2 contains an 'Active Summoning Revelation' script, plus east/west ritual anchors and a northern focus. Its script says living voices are sustaining the rite. No source evidence of the actual cult family staged as Actors/Token combatants, or of an ending after the discovery; ending remains creative TBD.

## Possible blockers requiring explicit verification

**High priority:**
- N3 route-overlay requires Recent Route Fragment in T3, while current N3→T3 unlock requires that overlay. No independently usable alternate entry to T3 was verified. **Potential circular progression lock, not yet proven absolute.**
- Old Estate Survey and Station Route Plate have registered Items and sockets, but no known structured/custom pickup scripts or explicit award logic. E1 hound exposes a plan fragment, and N3 locker accepts the Brass Baggage Token, yet those scripts only record state/feedback, not an award of these named Items. **Likely missing recovery hooks, subject to future GM/manual design review.**
- Imported maps exist on disk, but none of the 21 Scene background image fields point to them. **Visual installation gap.**
- Only four native Scene teleport behaviors were found. Other scene exits and railway links require installation and exact landing/owner safety checks.
- F2 reveals active summoning but lacks cult-family Actor/Token staging. The user-approved family's specific identities and aftermath should be developed with the owner, not invented as recovered canon.

**Additional audits:**
- The M1 clock, glass-eye and piano-roll scripts contain custom item checks or explicit GM gates that are not visible from merely reading the high-level contracts; always inspect full source before claiming a bypass.
- F1 inner ward relies on scene flags and a deliberate GM confirmation. F2 final arrival is not yet a certified safe player transfer.
- Item Icons are mostly generic Foundry icon references rather than custom illustrations; icon resources under Foundry's global icon root are outside the copied world-data file inventory.
- The copied State Ledger has some prior observed state, including E1 recentUseObserved true. Do not treat the snapshot as proof of untouched fresh-campaign progression without comparing an original reset receipt.
- The visual files passed existence/decode/dimension checks; a visual match to scene geometry, lighting, orientation and artwork meaning is not yet certified.

## Preserved companion evidence

- snapshot-provenance.json (109 files + individual SHA-256)
- full-evidence-catalog.json (all source behavior scripts, item registrations, State Ledger and Macros)
- audit-summary.json (scene list and first-pass contracts)
- enhanced-puzzle-interaction-audit.json (96 parsed contracts + manual Item references)
- THE-MYSTERIOUS-LODGE-ASSET-AND-PUZZLE-AUDIT.md (504-line room-by-room first-pass inventory; note multiline scripts are corrected by the enhanced audit)
- puzzle-interactions.csv, puzzle-dependencies.json
- unparsed-behavior-script-review.md (all nonstandard scripts, F1/F2 included)
- visual-actor-and-asset-inventory.json
- visual-artwork-file-manifest.json (26 images with hashes, dimensions, linkage status)

**No changes to the live/test Foundry world, campaign progression state, region scripts, background images, production campaign, or Bridge.** This is read-only recovery research. It is not Ready-to-Play certification.
