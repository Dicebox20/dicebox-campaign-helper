# The Mysterious Lodge — N3 hidden-spur dependency audit

**Status: completed source-only review. No Foundry or production world mutation.** Source: recovered copied test-world catalog, installed RegionBehavior source scripts, railway route planning manifest, and depot catalog/tests. The static evidence does NOT prove live reachability or successful actor Item grants.

## Actual recoverable chains (corrected)

- **Old Estate Survey is not missing.** The registered Item declares M2 as its source. After finding four crests and satisfying E4 mausoleum gate, the E4 Founder's Signet recovery grants the signet. In M2 the serialized `Founder Portrait Signet` source checks the actor carries that exact signet and runs a *nested pickup* for `old-estate-survey` with state `puzzles.m2.founderPortraitOpened`. That embedded pickup is not included as a top-level contract in the old parser.
- **Station Route Plate is not missing.** N3 `baggage-token-route-plate` first accepts `brass-baggage-token` (from M1 clock) and, on a PASS or ALREADY_INSTALLED response, calls the Kernel's *nested pickup* for `station-route-plate`, setting `puzzles.n3.stationRoutePlateResolved`.
- **Recent Route Fragment** has a GM-controlled acquisition routine physically located in T3. The routine requires player selection/confirmation; it is not automatically given.

## Exact circular dependency

1. N3 Cartography Route Overlay resolves only if three state flags are true: `oldEstateSurvey`, `cultPassageDiagram`, `recentRouteFragment`.
2. N3 `t3BranchUnlocked` requires all of `departureBoardResolved`, `switchWheelInstalled`, and `routeOverlay.resolved`.
3. `recent-route-fragment` is obtainable in T3, behind the N3 branch. The N3→T3 direct forward route is **not installed** in the dated route manifest.
4. The alternative station fast-travel catalog for T3 ALSO requires `puzzles.n3.t3BranchUnlocked`, alongside the overlay. It therefore cannot resolve the cycle.
5. Only four other directed native teleports were recovered: E1→M1, T3→N3, T3→F1, F1→F2. None is an entry into T3. The existing T3→N3 is a return direction, not an alternate entrance.

**Finding:** In the recovered design and installed source script topology, there is no verified legitimate path that obtains the T3 fragment before unlocking N3→T3. The cycle blocks intended progression unless another undocumented GM/manual entrance is used. 'No proven alternate entry' is not evidence that the author never intended one.

## Validated static components and open runtime work

- Pure depot menu and transfer-planning tests: **31 passed, 0 failed**, including locked destination suppression, stale ledger rejection and one-shot safety checks. These mocks do not execute actual Foundry token travel.
- `clscale-railway-master-route-manifest-v002.json`: seven physical adjacency plans, four existing one-way teleports. Unbound T1/T2 mouths and other reciprocal links remain uncertified.
- T3 forward transfer and exact safe arrival are separate implementation blockers. A logical branch unlock alone does NOT move the token.
- Foundry test-world and real runtime were not launched or modified during this review.

## Repair choices to confirm with campaign owner

**Option A, strongest continuity of existing clues:** make the Old Estate Survey + Cult Passage Diagram create a **preliminary overlay** sufficient to enter T3. Recover the Recent Route Fragment in T3; use it to finish the **complete overlay** on return, providing a later reveal. This keeps every recovered Item where it originally belongs but changes which phase controls `t3BranchUnlocked`.

**Option B, smallest logic/script change:** move the Recent Route Fragment pickup to a legitimately reachable room before T3 and retain the existing three-part overlay gate. This changes the authored Item's T3 placement.

**Option C, separate secret walkable entry:** build an alternate entrance to T3 from a reachable location while retaining the three-part overlay and existing Item locations. This adds a new route and may weaken the intended gated railway puzzle.

Do **not** implement any of these in live Foundry before the owner selects a creative progression shape and an exact-bound test-world plan passes the existing active-GM, single-writer, backup, return/landing and no-retry gates.

## Next bounded work unit

`MLODGE-N3-DESIGN-001`: owner chooses how to break the dependency cycle. Then stage a narrow **test-world** repair of the selected gate and safe N3→T3 physical transition, followed by clean-state pickup and gate tests. Preserve all unrelated scenes, actors and user data.

## Evidence paths

- `work/clscale-central-lodge-migration-v001/clscale-n3-dependency-audit-20261010.json`: assertion-checked extraction and alternative designs.
- `work/clscale-central-lodge-migration-v001/story-reconstruction-audit-20261010/full-evidence-catalog.json`: exact installed scripts and Item flags.
- `work/clscale-central-lodge-migration-v001/clscale-railway-master-route-manifest-v002.json`: planned direct/physical railway links and direction certification.
- `tools/clscale-depot-fast-travel-catalog.mjs` and `tools/clscale-depot-transfer-plan.mjs`: gated read-only catalog and precommit constraints.
- `work/clscale-central-lodge-migration-v001/clscale-depot-transfer-plan.test.mjs` and `clscale-depot-menu-runtime-mock.test.mjs`: 31 passing mocked static tests.
